package com.OBJ2100.ExamApp.entities;

/**
 * Abstraction for all entities in our domain model.
 * 
 * @author 7154
 *
 */
public interface Entity {

}
