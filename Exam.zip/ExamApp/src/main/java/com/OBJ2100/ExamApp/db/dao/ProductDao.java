package com.OBJ2100.ExamApp.db.dao;

import java.util.List;

import com.OBJ2100.ExamApp.entities.Product;

public interface ProductDao {
	List<Product> getAll();
}
