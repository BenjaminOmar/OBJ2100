package com.OBJ2100.ExamApp.db.dao;

import java.util.List;

import com.OBJ2100.ExamApp.entities.Office;

public interface OfficeDao {
	List<Office> getAll();
	List<Office> getCustomerByCountry(String country);
}

